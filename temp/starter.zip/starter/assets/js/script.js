$( document ).ready(function() {
// Handler for .ready() called.
$( "#one" ).click(function(){
alert( "Handler for .click() called." );
});
});



