<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">

  <title>Test Natural Intelligence </title>

  <link rel="stylesheet" href="assets/css/layout.css?v=1.0">
  <script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
  <script src="assets/js/script.js"></script>
</head>

<body>
    <?php 
        require_once 'class/mysql_crud.php';
        $db = new Database();
        $db->connect();
        $result = @mysql_query("SELECT * FROM `cars`");
        $result1 = @mysql_query("SELECT SUM(price) sum FROM `cars`");
        $sum = mysql_fetch_object($result1);
            echo "<table border='1' id='table1'>
            <tr>
            <th>#Pos</th>
            <th>Model</th>
            <th>Price</th>
            <th>Image</th>
            </tr>";
            
            while($row = mysql_fetch_array($result, MYSQL_ASSOC))
            {
            echo "<tr>";
            echo "<td>" . $row['pos'] . "</td>";
            echo "<td>" . $row['model'] . "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "<td>" . $row['image'] . "</td>";
            echo "</tr>";
            }
            echo "<tr id='last'>";
            echo "<td>"."</td>";
            echo "<td>" ."</td>";
            echo "<td>" . $sum->sum . "</td>";
            echo "<td>". "</td>";
            echo "</tr>";
            echo "</table>";
        

//var_dump($result);
    ?>
    <!--<ul id="start"></ul>

    <script src="//code.jquery.com/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/mustache.js/0.7.0/mustache.min.js"></script>
    <script type="mustache/x-tmpl" id="name_matches_tmpl">
     <table border='1' id='table1'>
            <tr>
            <th>#Pos</th>
            <th>Model</th>
            <th>Price</th>
            <th>Image</th>
            </tr>
        
      {{#matches}}
      <tr>
      <td>{{pos}}</td>
      <td>{{model}}</td>
      <td>{{price}}</td>
      <td>{{image}}</td>
      </tr>
      {{/matches}}
      <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>1{{#sum}}{{sum}}{{/sum}}1</td>
      </tr>
      {{^matches}}
      <li><em>No matches found </em></li>
      {{/matches}}
    </script>
    -->
    
    
    
    
    
    
    <input type="submit" name="submit" id="sort" value="show only asian cars" />
    
    
    <ul id="results"></ul>

    <script src="//code.jquery.com/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/mustache.js/0.7.0/mustache.min.js"></script>
    <script type="mustache/x-tmpl" id="name_matches_tmpl">
     <table border='1' id='table1'>
            <tr>
            <th>#Pos</th>
            <th>Model</th>
            <th>Price</th>
            <th>Image</th>
            </tr>
        
      {{#matches}}
      <tr>
      <td>{{pos}}</td>
      <td>{{model}}</td>
      <td>{{price}}</td>
      <td>{{image}}</td>
      </tr>
      {{/matches}}
      
      {{^matches}}
      <li><em>No matches found </em></li>
      {{/matches}}
    </script>
    
    
    
    <script>
        
        $("#sort").click(function(e){
                var data = '';
                  $.ajax({
                  url: "sort.php",
                  data: data,
                  type: "post",
                  dataType: "json",
                  success: function(res) {
                      var tmpl = $("#name_matches_tmpl").html();
                      var html = Mustache.to_html(tmpl, res);
                      $("#table1").html(html);
                  }
                  });
         });
         $( document ).ready(function() {
                var data = '';
                  $.ajax({
                  url: "sort.php?start=true",
                  data: data,
                  type: "post",
                  dataType: "json",
                  success: function(res) {
                      var tmpl = $("#name_matches_tmpl").html();
                      var html = Mustache.to_html(tmpl, res);
                      $("#start").html(html);
                  }
                  });
         });

</script>
</body>
</html>